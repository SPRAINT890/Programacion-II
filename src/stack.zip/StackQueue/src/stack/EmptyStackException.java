package StackQueue.src.stack;

public class EmptyStackException extends Exception {
}
