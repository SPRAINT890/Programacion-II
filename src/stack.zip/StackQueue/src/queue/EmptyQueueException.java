package StackQueue.src.queue;

public class EmptyQueueException extends Exception {

}
